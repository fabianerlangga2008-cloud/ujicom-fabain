<!DOCTYPE html>
<html>
<head>
    <title>Tambah Aspirasi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: sans-serif; background: #f4f7f6; padding: 20px; }
        .form-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h3 { color: #2c3e50; margin-bottom: 20px; }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input, textarea, select { width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { background: #2ecc71; color: white; border: none; padding: 12px; width: 100%; border-radius: 4px; margin-top: 20px; cursor: pointer; font-weight: bold; }
        .btn-kembali { display: block; text-align: center; margin-top: 10px; color: #7f8c8d; text-decoration: none; }
    </style>
</head>
<body>

<div class="form-container">
    <h3>Input Aspirasi Baru</h3>
    <form action="../controller/c_proses_tambah.php" method="POST">
        <label>NIS:</label>
        <input type="text" name="nis" placeholder="Contoh: 4022" required>
        
        <label>Kategori:</label>
        <select name="id_kategori" required>
            <option value="">-- Pilih Kategori --</option>
            <option value="1">Fasilitas</option>
        </select>
        
        <label>Lokasi:</label>
        <input type="text" name="lokasi" placeholder="Misal: Kelas XI RPL" required>
        
        <label>Laporan:</label>
        <textarea name="ket" rows="5" placeholder="Jelaskan detail masalah..." required></textarea>
        
        <button type="submit" name="simpan">KIRIM LAPORAN</button>
        <a href="dashboard.php" class="btn-kembali">Kembali ke Dashboard</a>
    </form>
</div>

</body>
</html>
