<?php
include_once '../controller/c_aspirasi.php';
$ctrl = new c_Aspirasi();
$data = $ctrl->detailLaporan($_GET['id']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Laporan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: sans-serif; background: #f4f7f6; padding: 20px; }
        .form-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 10px; font-weight: bold; font-size: 14px; }
        input, textarea, select { width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { background: #f39c12; color: white; border: none; padding: 12px; width: 100%; border-radius: 4px; margin-top: 20px; cursor: pointer; }
    </style>
</head>
<body>

<div class="form-card">
    <h3>Edit Laporan #<?= $data['id_pelaporan']; ?></h3>
    <form action="../controller/c_proses_edit.php" method="POST">
        <input type="hidden" name="id" value="<?= $data['id_pelaporan']; ?>">
        
        <label>Lokasi:</label>
        <input type="text" name="lokasi" value="<?= $data['lokasi']; ?>" required>
        
        <label>Laporan:</label>
        <textarea name="ket" rows="5" required><?= $data['ket']; ?></textarea>
        
        <label>Status:</label>
<select name="status"> <option value="Menunggu" <?= ($data['status'] == 'Menunggu') ? 'selected' : ''; ?>>Menunggu</option>
    <option value="proses" <?= ($data['status'] == 'proses') ? 'selected' : ''; ?>>Diproses</option>
    <option value="selesai" <?= ($data['status'] == 'selesai') ? 'selected' : ''; ?>>Selesai</option>
</select>


        <button type="submit" name="simpan">Simpan Perubahan</button>
    </form>
</div>

</body>
</html>
