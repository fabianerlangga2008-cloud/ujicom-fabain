<?php
// Pastikan path controller benar
include_once '../controller/c_aspirasi.php';
$ctrl = new c_aspirasi();

// Mengambil data berdasarkan ID dari URL
$data = $ctrl->detailLaporan($_GET['id']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Aspirasi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: sans-serif; background: #f4f7f6; padding: 20px; }
        .detail-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h3 { color: #2c3e50; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .info-group { margin-bottom: 15px; }
        .label { font-weight: bold; color: #7f8c8d; font-size: 12px; text-transform: uppercase; }
        .value { font-size: 16px; color: #2c3e50; margin-top: 5px; background: #f9f9f9; padding: 8px; border-radius: 4px; }
        .status-badge { display: inline-block; padding: 5px 10px; border-radius: 20px; color: white; font-size: 12px; }
        .btn-kembali { display: block; text-align: center; margin-top: 20px; background: #34495e; color: white; padding: 10px; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>

<div class="detail-container">
    <h3>Detail Laporan #<?= $data['id_pelaporan']; ?></h3>
    
    <div class="info-group">
        <div class="label">NIS Pelapor</div>
        <div class="value"><?= $data['nis']; ?></div>
    </div>

    <div class="info-group">
        <div class="label">Lokasi Kejadian</div>
        <div class="value"><?= $data['lokasi']; ?></div>
    </div>

    <div class="info-group">
        <div class="label">Isi Aspirasi / Laporan</div>
        <div class="value" style="min-height: 100px;"><?= nl2br($data['ket']); ?></div>
    </div>

    <div class="info-group">
        <div class="label">Status Saat Ini</div>
        <div class="value">
            <span class="status-badge" style="background: <?= ($data['status'] == 'Selesai') ? '#2ecc71' : '#f1c40f'; ?>">
                <?= $data['status'] ?? 'Menunggu'; ?>
            </span>
        </div>
    </div>

    <a href="dashboard.php" class="btn-kembali">Kembali ke Dashboard</a>
</div>

</body>
</html>
