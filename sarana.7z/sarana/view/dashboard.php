<?php
include_once '../controller/c_aspirasi.php';
$ctrl = new c_Aspirasi();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <style>
        body { font-family: sans-serif; background: #f4f7f6; margin: 0; padding: 20px; }
        .stats-container { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; }
        .card { background: white; padding: 15px; border-radius: 8px; min-width: 120px; flex: 1; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .card h3 { margin: 5px 0; font-size: 24px; color: #2c3e50; }
        .card p { margin: 0; font-size: 12px; color: #7f8c8d; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; font-size: 13px; }
        th { background: #34495e; color: white; }
        .filter-box { margin-bottom: 15px; background: white; padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>

    <h2>Selamat Datang, Fabian - Admin</h2>

    <div class="stats-container">
        <div class="card" style="border-top: 5px solid #e74c3c;">
            <h3><?= $ctrl->getStats('Menunggu'); ?></h3>
            <p>Menunggu</p>
        </div>
        <div class="card" style="border-top: 5px solid #2ecc71;">
            <h3><?= $ctrl->getStats('proses'); ?></h3>
            <p>Diproses</p>
        </div>
        <div class="card" style="border-top: 5px solid #3498db;">
            <h3><?= $ctrl->getStats('selesai'); ?></h3>
            <p>Selesai</p>
        </div>
        <div class="card" style="border-top: 5px solid #9b59b6;">
            <h3><?= $ctrl->getStats(); ?></h3>
            <p>Total Data</p>
        </div>
    </div>

    
        </form>
<div style="margin-bottom: 10px;">
    <a href="v_tambah_aspirasi.php" style="background: #2ecc71; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; font-size: 13px;">+ Tambah Aspirasi (Create)</a>
</div>

<table border="1">
    <tr>
        <th>No</th>
        <th>NIS</th>
        <th>Pesan</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>
    <?php
    $data = $ctrl->tampilData($_GET['tgl']??'', $_GET['bln']??'', $_GET['cari']??'');
    $no = 1;
    while($row = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['nis']; ?></td>
            <td><?= $row['ket']; ?></td>
            <td><?= $row['status'] ?? 'Menunggu'; ?></td>
            <td>
                <a href="v_detail.php?id=<?= $row['id_pelaporan']; ?>" style="color: blue;">Lihat</a> | 
                
                <a href="v_edit.php?id=<?= $row['id_pelaporan']; ?>" style="color: orange;">Edit</a> | 
                
                <a href="../controller/proses_hapus.php?id=<?= $row['id_pelaporan']; ?>" 
                   onclick="return confirm('Yakin ingin menghapus data ini?')" style="color: red;">Hapus</a>
            </td>
        </tr>
    <?php } ?>
</table>


</body>
</html>
