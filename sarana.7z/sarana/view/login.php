<?php
session_start();
include "../model/koneksi.php";

$error = ""; // Variabel untuk menampung pesan error

if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Menggunakan Prepared Statement untuk mencegah SQL Injection
    $query = "SELECT * FROM admin WHERE username = ? AND password = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    
    // "ss" artinya data yang dikirim adalah dua buah String
    mysqli_stmt_bind_param($stmt, "ss", $user, $pass);
    mysqli_stmt_execute($stmt);
    
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        
        // Simpan data ke session
        $_SESSION['username'] = $data['username'];
        $_SESSION['status']   = "login";

        // Pindah ke halaman dashboard
        header("Location: dashboard.php");
        exit(); 
    } else {
        $error = "Username atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body { 
            background: #2f4050; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0;
        }
        .login-box { 
            background: white; 
            padding: 40px; 
            border-radius: 10px; 
            width: 320px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }
        .login-box h2 { text-align: center; color: #333; margin-bottom: 20px; }
        input { 
            width: 100%; 
            padding: 12px; 
            margin: 10px 0; 
            border: 1px solid #ccc; 
            border-radius: 5px; 
            box-sizing: border-box; /* Agar padding tidak merusak lebar */
        }
        button { 
            width: 100%; 
            background: #1ab394; 
            color: white; 
            border: none; 
            padding: 12px; 
            cursor: pointer; 
            border-radius: 5px; 
            font-weight: bold;
            transition: 0.3s;
        }
        button:hover { background: #18a689; }
        .error-msg {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            font-size: 13px;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h2>Login</h2>

        <?php if($error != ""): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label>Username</label>
            <input type="text" name="username" placeholder="Masukkan Username" required>
            
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukkan Password" required>
            
            <button type="submit" name="login">MASUK</button>
        </form>
    </div>

</body>
</html>
