<?php
class m_user {
    private $koneksi;

    public function __construct() {
        $host = "127.0.0.1";
        $user = "root";
        $pass = "root";
        $db   = "UKK_PAKET3";

        $this->koneksi = mysqli_connect($host, $user, $pass, $db);

        if (!$this->koneksi) {
            die("Koneksi Database Gagal: " . mysqli_connect_error());
        }
    }

    public function tampil_data() {
        // Sesuaikan 'pengaduan' dengan nama tabel Anda
        $query = "SELECT * FROM pengaduan";
        $result = mysqli_query($this->koneksi, $query);
        
        $data = [];
        if ($result) {
            while ($row = mysqli_fetch_object($result)) {
                $data[] = $row;
            }
        }
        return $data;
    }
}
?>
