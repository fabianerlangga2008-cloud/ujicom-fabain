<?php
$koneksi = mysqli_connect("127.0.0.1","root","root","UKK_PAKET3");

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
