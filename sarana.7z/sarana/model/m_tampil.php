<?php
//memanggil koneksi kedatabase
include_once "koneksi.php";

//membuat kelas user
class m_user{
  
  //membuat fungsi untuk menampilkan data dari tabel user
  public function tampil_data_user(){
    
    //membuat objek dari kelas m_koneksi
    $con = new m_koneksi();
    
    
    //membuat query untuk menampilkan semua data dari tabel user
    $sql = "SELECT * FROM user";
    
    //perintah untuk menjalankan query di atas
   $post =  mysqli_query($con->koneksi, $sql);
   //var_dump(mysqli_fetch_object($post));
   //exit;
    // mengecek apakah hasil variabel $post ada datanya atau tidak
    if($post->num_rows > 0){
      //merubah data daei variabel $post menjadi data berbentuk objek
      
      while($data = mysqli_fetch_object($post)){
        //menyimpan data objek kedalam variabel $result yg berbentuk array
        $result[] = $data;
      }
      //kembalikan nilai nya
      return $result;
    }else{
      echo "tidak ada data";
    }
  }
}