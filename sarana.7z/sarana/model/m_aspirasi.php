<?php
class m_aspirasi {
    private $conn;

    public function __construct() {
        $this->conn = mysqli_connect("127.0.0.1", "root", "root", "UKK_PAKET3");
        if (!$this->conn) {
            die("Koneksi gagal: " . mysqli_connect_error());
        }
    }

    // FUNGSI DELETE (Yang menyebabkan error di screenshot kamu)
    public function delete($id) {
        $id = mysqli_real_escape_string($this->conn, $id);
        
        // 1. Hapus dulu data di tabel status (aspirasi) jika ada
        mysqli_query($this->conn, "DELETE FROM aspirasi WHERE id_pelaporan = '$id'");
        
        // 2. Kemudian hapus data utama di tabel input_aspirasi
        $query = "DELETE FROM input_aspirasi WHERE id_pelaporan = '$id'";
        return mysqli_query($this->conn, $query);
    }

    // FUNGSI UPDATE (Untuk memperbaiki fitur edit yang belum jalan)
    public function update($id, $lokasi, $ket, $status) {
        $id = mysqli_real_escape_string($this->conn, $id);
        $lokasi = mysqli_real_escape_string($this->conn, $lokasi);
        $ket = mysqli_real_escape_string($this->conn, $ket);
        $status = mysqli_real_escape_string($this->conn, $status);

        // Update data utama
        mysqli_query($this->conn, "UPDATE input_aspirasi SET lokasi='$lokasi', ket='$ket' WHERE id_pelaporan='$id'");

        // Sinkronisasi tabel status
        $cek = mysqli_query($this->conn, "SELECT * FROM aspirasi WHERE id_pelaporan='$id'");
        if (mysqli_num_rows($cek) > 0) {
            $q_status = "UPDATE aspirasi SET status='$status', tanggal_update=NOW() WHERE id_pelaporan='$id'";
        } else {
            $q_status = "INSERT INTO aspirasi (id_pelaporan, status, tanggal_update) VALUES ('$id', '$status', NOW())";
        }
        return mysqli_query($this->conn, $q_status);
    }

    // FUNGSI READ (Agar data muncul di dashboard)
    public function getAspirasiFiltered($tgl, $bln, $cari) {
        $query = "SELECT i.*, a.status 
                  FROM input_aspirasi i 
                  LEFT JOIN aspirasi a ON i.id_pelaporan = a.id_pelaporan 
                  WHERE 1=1";
        
        if($tgl) $query .= " AND DAY(i.tanggal_input) = '$tgl'";
        if($bln) $query .= " AND MONTH(i.tanggal_input) = '$bln'";
        if($cari) {
            $cari = mysqli_real_escape_string($this->conn, $cari);
            $query .= " AND (i.nis LIKE '%$cari%' OR i.ket LIKE '%$cari%')";
        }
        
        $query .= " ORDER BY i.tanggal_input DESC";
        return mysqli_query($this->conn, $query);
    }

    // FUNGSI CREATE
    public function insert($nis, $id_kat, $lokasi, $ket) {
        $tgl = date('Y-m-d H:i:s');
        $query = "INSERT INTO input_aspirasi (nis, id_kategori, lokasi, ket, tanggal_input) 
                  VALUES ('$nis', '$id_kat', '$lokasi', '$ket', '$tgl')";
        return mysqli_query($this->conn, $query);
    }

    public function getById($id) {
        $id = mysqli_real_escape_string($this->conn, $id);
        $res = mysqli_query($this->conn, "SELECT i.*, a.status FROM input_aspirasi i LEFT JOIN aspirasi a ON i.id_pelaporan = a.id_pelaporan WHERE i.id_pelaporan = '$id'");
        return mysqli_fetch_assoc($res);
    }

    public function getStats() {
        $res = mysqli_query($this->conn, "SELECT COUNT(*) as total FROM input_aspirasi");
        $data = mysqli_fetch_assoc($res);
        return $data['total'] ?? 0;
    }
}
