<?php
include_once 'c_aspirasi.php';

if (isset($_POST['simpan'])) { // Menyesuaikan name="tambah" dari form
    $nis = $_POST['nis'];
    $id_kat = $_POST['id_kategori'];
    $lokasi = $_POST['lokasi'];
    $ket = $_POST['ket'];

    $ctrl = new c_aspirasi();
    $ctrl->tambahAspirasi($nis, $id_kat, $lokasi, $ket);
}
