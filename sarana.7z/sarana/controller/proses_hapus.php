<?php
include_once 'c_aspirasi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $ctrl = new c_aspirasi();
    $ctrl->hapusLaporan($id);
}
