<?php
include_once '../model/m_aspirasi.php';

class c_aspirasi {
    private $model;

    public function __construct() {
        $this->model = new m_aspirasi();
    }

    public function getStats() {
        return $this->model->getStats();
    }

    public function tampilData($tgl, $bln, $cari) {
        return $this->model->getAspirasiFiltered($tgl, $bln, $cari);
    }

    public function tambahAspirasi($nis, $id_kat, $lokasi, $ket) {
        if($this->model->insert($nis, $id_kat, $lokasi, $ket)) {
            header("Location: ../view/dashboard.php?msg=tambah_sukses");
        }
    }

    public function editLaporan($id, $lokasi, $ket, $status) {
        if($this->model->update($id, $lokasi, $ket, $status)) {
            header("Location: ../view/dashboard.php?msg=edit_sukses");
        } else {
            echo "Gagal memperbarui data.";
        }
    }

    public function hapusLaporan($id) {
        if($this->model->delete($id)) {
            header("Location: ../view/dashboard.php?msg=hapus_sukses");
        }
    }

    public function detailLaporan($id) {
        return $this->model->getById($id);
    }
}
