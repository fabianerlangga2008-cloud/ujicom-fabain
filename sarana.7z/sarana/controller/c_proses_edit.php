<?php
include_once 'c_aspirasi.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $lokasi = $_POST['lokasi'];
    $ket = $_POST['ket'];
    $status = $_POST['status'];

    $ctrl = new c_aspirasi();
    // Mengirim 4 parameter ke fungsi update
    $ctrl->editLaporan($id, $lokasi, $ket, $status);
}
