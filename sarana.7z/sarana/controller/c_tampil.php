<?php
// Pastikan path ini benar: keluar satu tingkat lalu masuk ke folder model
require_once __DIR__ . "/../model/m_user.php";

$model = new m_user();
$user  = $model->tampil_data();
?>
